git init
git add README.md
git commit -m "first commit"
git remote add origin https://github.com/teshlya/reddit.git
git push -u origin master