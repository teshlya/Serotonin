package teshlya.com.reddit.callback;

import teshlya.com.reddit.model.Subscription;

public interface CallbackCommunity {
    void addCommunity(Subscription subscription);
}
