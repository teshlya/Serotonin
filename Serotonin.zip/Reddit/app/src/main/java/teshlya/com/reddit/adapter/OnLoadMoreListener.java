package teshlya.com.reddit.adapter;

public interface OnLoadMoreListener {
    void onLoadMore();
}
