package tellh.com.recyclertreeview_lib;

/**
 * Created by tlh on 2016/10/1 :)
 */

public interface LayoutItemType {
    int getLayoutId();
}
